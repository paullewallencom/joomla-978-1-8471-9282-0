<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

$mainframe->registerEvent('onGetWebServices', 'plgXMLRPCFoobar');

/**
 * Gets the available XML-RPC functions
 *
 * @return array Definition of the available XML-RPC functions
 */
function plgXMLRPCFoobar()
{
    // get the XMl-RPC types
    global $xmlrpcI4, $xmlrpcInt, $xmlrpcBoolean, $xmlrpcDouble, $xmlrpcString, $xmlrpcDateTime, $xmlrpcBase64, $xmlrpcArray, $xmlrpcStruct, $xmlrpcValue;

    // return the definitions
    return array
     (
        // addition service
        'foobar.add' => array
        (
            'function' => 'plgXMLRPCFoobarServices::add',
            'docstring' => 'Adds two numbers.',
            'signature' => array(array($xmlrpcStruct, $xmlrpcDouble, $xmlrpcDouble))
        ),
        // subtraction service
        'foobar.subtract' => array
        (
            'function' => 'plgXMLRPCFoobarServices::subtract',
            'docstring' => 'Multiplies two numbers.',
            'signature' => array(array($xmlrpcStruct, $xmlrpcDouble, $xmlrpcDouble))
        )
    );
}

/**
 * Foobar XML-RPC service handler
 *
 * @static
 */
class plgXMLRPCFoobarServices
{
    /**
     * Adds values together
     *
     * @static
     * @param float xmlrpcDouble
     * @param float xmlrpcDouble
     * @return xmlrpcresp xmlrpcDouble
     */
    function add($value1, $value2)
    {
        global $xmlrpcDouble, $xmlrpcStruct;
    
        // determine the product of the two values
        $product = $value1 + $value2;

        // build the struct response
        $result = new xmlrpcval(array(
			'value1' => new xmlrpcval($value1, $xmlrpcDouble),
			'value2' => new xmlrpcval($value2, $xmlrpcDouble),
			'product' => new xmlrpcval($product, $xmlrpcDouble)
			), $xmlrpcStruct);

        // encapsulate the response value and return it
        return new xmlrpcresp($result);
        
    }

    /**
     * Subtracts a value from another
     *
     * @static
     * @param float xmlrpcDouble
     * @param float xmlrpcDouble
     * @return xmlrpcresp xmlrpcDouble
     */
    function subtract($value1, $value2)
    {
        global $xmlrpcDouble, $xmlrpcStruct;

        // determine the product of the two values
        $product = $value1 - $value2;

        // build the struct response
        $result = new xmlrpcval(array(
			'value1' => new xmlrpcval($value1, $xmlrpcDouble),
			'value2' => new xmlrpcval($value2, $xmlrpcDouble),
			'product' => new xmlrpcval($product, $xmlrpcDouble)
			), $xmlrpcStruct);

        // encapsulate the response value and return it
        return new xmlrpcresp($result);
    }
}

?>