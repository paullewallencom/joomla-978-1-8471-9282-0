<?php
$document =& JFactory::getDocument();
$document->setName('Some Name');
$document->setTitle('Some Title');
$document->setDescription('Some Description');
$document->setMetaData('keywords', 'Some Keywords');
$document->setGenerator('Some Generator');
?>