<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <th>Name</th>
        <td><?php echo $this->foobar->name; ?></td>
    </tr>
    <tr>
        <th>Description</th>
        <td><?php echo $this->foobar->description; ?></td>
    </tr>
</table>