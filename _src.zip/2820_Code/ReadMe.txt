******************

This folder contains the codes for "Mastering Joomla! 1.5 Extension and Framework
Development" book. The codes have been arranged chapter-wise, for example the folder named "Chapter02" 
contains all the code files for Chapter 2.

Total no. of folders (chapter-wise) = 10


******************